const { getStore } = require("@netlify/blobs");
const { randomBytes } = require("node:crypto");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "Method not allowed" });
  try {
    const { email } = JSON.parse(event.body || "{}");
    if (typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return reply(400, { error: "Укажи правильную электронную почту." });
    }
    const token = randomBytes(18).toString("hex");
    const store = getStore("pg-invitations");
    await store.setJSON(token, {
      ownerEmail: email.trim().toLowerCase(),
      createdAt: new Date().toISOString(),
      answered: false
    });
    const origin = event.headers.origin || process.env.URL;
    return reply(200, { token, url: `${origin}/?invite=${token}` });
  } catch (err) {
    console.error(err);
    return reply(500, { error: "Не удалось создать приглашение." });
  }
};
function reply(statusCode, body) {
  return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(body) };
}
