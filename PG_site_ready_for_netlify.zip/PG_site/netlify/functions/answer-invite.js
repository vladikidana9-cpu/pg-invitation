const { getStore } = require("@netlify/blobs");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "Method not allowed" });
  try {
    const { token, choice, answers } = JSON.parse(event.body || "{}");
    if (typeof token !== "string" || !/^[a-f0-9]{36}$/.test(token)) return reply(400, { error: "Неверная ссылка." });
    if (!["yes", "no"].includes(choice)) return reply(400, { error: "Неизвестный ответ." });
    if (choice === "yes" && (!Array.isArray(answers) || answers.length !== 4 || answers.some(x => typeof x !== "string" || !x.trim() || x.length > 300))) {
      return reply(400, { error: "Заполни все четыре ответа." });
    }
    const store = getStore("pg-invitations");
    const invite = await store.get(token, { type: "json" });
    if (!invite) return reply(404, { error: "Приглашение не найдено." });
    if (invite.answered) return reply(409, { error: "На это приглашение уже ответили." });

    const apiKey = process.env.RESEND_API_KEY;
    const from = process.env.FROM_EMAIL;
    if (!apiKey || !from) return reply(503, { error: "Отправка писем ещё не настроена владельцем сайта." });

    const subject = choice === "yes" ? "Друг согласился погулять! 💙" : "Ответ на приглашение ПГ";
    const text = choice === "yes"
      ? `Друг согласился погулять!\n\nИмя: ${answers[0]}\nДата: ${answers[1]}\nВремя: ${answers[2]}\nМесто: ${answers[3]}`
      : "Сожалеем, с вами не захотели погулять 😢";
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [invite.ownerEmail], subject, text })
    });
    if (!response.ok) {
      const detail = await response.text();
      console.error("Resend error:", detail);
      return reply(502, { error: "Сервис почты не смог отправить письмо. Попробуй позже." });
    }
    invite.answered = true;
    invite.answeredAt = new Date().toISOString();
    invite.choice = choice;
    await store.setJSON(token, invite);
    return reply(200, { ok: true });
  } catch (err) {
    console.error(err);
    return reply(500, { error: "Не удалось отправить ответ." });
  }
};
function reply(statusCode, body) {
  return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(body) };
}
