const { getStore } = require("@netlify/blobs");

exports.handler = async (event) => {
  if (event.httpMethod !== "GET") return reply(405, { error: "Method not allowed" });
  const token = event.queryStringParameters?.token || "";
  if (!/^[a-f0-9]{36}$/.test(token)) return reply(400, { error: "Неверная ссылка." });
  try {
    const invite = await getStore("pg-invitations").get(token, { type: "json" });
    if (!invite) return reply(404, { error: "Такого приглашения нет или ссылка устарела." });
    return reply(200, { invite: { createdAt: invite.createdAt } });
  } catch (err) {
    console.error(err);
    return reply(500, { error: "Не удалось проверить приглашение." });
  }
};
function reply(statusCode, body) {
  return { statusCode, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }, body: JSON.stringify(body) };
}
